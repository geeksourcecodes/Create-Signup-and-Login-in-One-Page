// JavaScript Document
$(function(){
	$("#login_btn").click(function(){
		$("#login_btn").hide();
		$("#error_message").html("<img src=''images/loading.gif>");
		
		var username = $("#username").val();
		var password = $("#password").val();
		
		$.post("login.php", {username: username, password: password})
		.done(function(data){
			if(data =="success"){
				windom.location ="../dashboard";
			}else
			{
				$("#error_message").text("Invalid Details Supply, Try again");
				$("#login_btn").show();
			}
		});
	});
});