<?php
														// signup script goes here
														$message = '';
														if(isset($_POST['btn_signup']))
                                                        {
                                                        $name = $_POST['name'];
                                                        $username = $_POST['username'];	
                                                        $email = $_POST['email'];
                                                        $password = $_POST['password'];
                                                         require_once 'connect.php';	
                                                       $query = mysqli_query ($conn, "INSERT INTO user_tb(us_id, us_name, us_username, us_email, us_password, us_regdate) 
													   VALUES (NULL, '$name', '$username','$email', '$password',NOW())");
                                                        
                                                        if($query)
                                                        	{
                                                        	$message = "<div class='alert alert-dismissible alert-success'><strong> Your registration was successful.</strong></div>";
                                                        	
                                                        	
                                                        	}
															else
                                                        	{
                                                        	$message = "<div class='alert alert-dismissible alert-warning'><strong> Registration Failed.</strong></div>";
                                                        	
                                                        	}
														 }
														 // end of signup script
														 
												// login script start here
														 $login_message = '';
														if(isset($_POST['btn_signin']))
                                                        {
                                                       $lusername = $_POST['lusername'];	
                                                       $lpassword = $_POST['lpassword'];
                                                         require_once 'connect.php';	
                                                       $query = mysqli_query ($conn, "SELECT us_id, us_username, us_password FROM user_tb WHERE us_username = '$lusername' AND us_password ='$lpassword'");
                                                        $count = mysqli_num_rows($query);
														$row_login = mysqli_fetch_array($query);
														
														if ($count > 0)
														{
														 	$login_message = "<div class='alert alert-dismissible alert-success'><strong> You have successfully login.</strong></div>";
                                                        }
															else
                                                        	{
                                                        	$login_message = "<div class='alert alert-dismissible alert-warning'><strong> Login Failed.</strong></div>";
                                                        	
                                                        	}
														 }
                                                      
												 
  ?>
                                                         
													
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sign up and login in one place Template</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/small-business.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Start One Page Signup and Login</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
     
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <!-- Heading Row -->
    <div class="row align-items-center my-5">
      <div class="col-lg-6">
	<?php echo $message;?>
	  <p><form name="result_checker" method="post">
  <fieldset>
    <legend>Sign Up Here</legend><hr>
    
    <div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Name</strong></label>
      <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Name" >
      
    </div>
     <div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Email</strong></label>
      <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Email" >
      
    </div>
      <div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Username</strong></label>
      <input type="text" class="form-control" name="username" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Username">
      
    </div>
	
	<div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Password</strong></label>
      <input type="password" class="form-control" name="password" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Password">
      
    </div>
   
    <button type="submit" name="btn_signup" class="btn btn-block btn-primary btn-lg btn-rounded">Sign Up</button>
  </fieldset>
</form></p>
        
      </div>
      <!-- /.col-lg-8 -->
      <div class="col-lg-5">
	  <p><form name="result_checker" method="post">
	  <?php echo $login_message;?>
  <fieldset>
    <legend>Sign In Here</legend><hr>
    
    <div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Username</strong></label>
      <input type="text" class="form-control" name="lusername" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username" required>
      
    </div>
	
	<div class="form-group">
      <label for="exampleInputEmail1"><strong>Enter Password</strong></label>
      <input type="password" class="form-control" name="lpassword" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Password" required>
      
    </div>
     
    <button type="submit" name="btn_signin" class="btn btn-block btn-primary btn-lg btn-rounded">Sign-In</button>
  </fieldset>
</form>
</p>
        
      </div>
      <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
